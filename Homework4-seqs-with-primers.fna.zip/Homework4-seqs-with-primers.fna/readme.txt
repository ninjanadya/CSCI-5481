Nadya Postolaki
# Nadya Postolaki
# posto018
# CSCI 5481 HW 4

#IMPORTANT INFO:
#Code runs on Python 3
#To run in terminal:
#	$ python3 hw4.py

couldnt quite get part 3 to work so I just eyeballed the rest for part 4
sorry for making it 15 min late... I was trying to get part 3 to work
